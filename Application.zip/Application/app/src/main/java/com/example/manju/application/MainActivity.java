package com.example.manju.application;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
        EditText et1,et2,et3,et4;
        TextView tv1,tv2,tv3,tv4;
        Button bt;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1=(EditText)findViewById(R.id.in1);
        et2= (EditText) findViewById(R.id.in2);
        et3=(EditText)findViewById(R.id.in3);
        et4= (EditText) findViewById(R.id.in4);
        tv1= (TextView) findViewById(R.id.out1);
        tv2= (TextView) findViewById(R.id.out2);
        tv3= (TextView) findViewById(R.id.out3);
        tv4= (TextView) findViewById(R.id.out4);

        bt= (Button) findViewById(R.id.sbt1);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {

                String name=et1.getText().toString();
                tv1.setText(name);
                String college=et2.getText().toString();
                tv2.setText(college);
                String city=et3.getText().toString();
                tv3.setText(city);
                String dob=et4.getText().toString();
                tv4.setText(dob);
            }
        });
    }

}
